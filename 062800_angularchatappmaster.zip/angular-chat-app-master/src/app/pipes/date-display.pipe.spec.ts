import { DateDisplayPipe } from './date-display.pipe';

describe('DateDisplayPipe', () => {
  it('create an instance', () => {
    const pipe = new DateDisplayPipe();
    expect(pipe).toBeTruthy();
  });
});
