export const environment = {
  firebase: {
    // Your firebase config here
  },
  production: true,
};
